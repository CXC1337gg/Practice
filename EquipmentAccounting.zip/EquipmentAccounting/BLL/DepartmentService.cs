﻿using DAL;
using Entity;

namespace BLL
{
    public class DepartmrntService
    {
        public class DepartmentService
        {
            public List<Department> GetAll()
            {
                using (var db = new DLADbContext())
                {
                    return db.Departments
                        .OrderBy(d => d.Name)
                        .ToList();
                }
            }

            public Department? GetById(int id)
            {
                using (var db = new DLADbContext())
                {
                    return db.Departments.FirstOrDefault(d => d.Id == id);
                }
            }

            public void Add(string name)
            {
                using (var db = new DLADbContext())
                {
                    name = (name ?? "").Trim();
                    if (string.IsNullOrWhiteSpace(name))
                        throw new System.ArgumentException("Название подразделения не должно быть пустым.");

                    bool exists = db.Departments.Any(d => d.Name == name);
                    if (exists)
                        throw new System.InvalidOperationException("Подразделение с таким названием уже существует.");

                    db.Departments.Add(new Department { Name = name });
                    db.SaveChanges();
                }
            }

            public void Update(int id, string name)
            {
                using (var db = new DLADbContext())
                {
                    name = (name ?? "").Trim();
                    if (string.IsNullOrWhiteSpace(name))
                        throw new System.ArgumentException("Название подразделения не должно быть пустым.");

                    var dep = db.Departments.FirstOrDefault(d => d.Id == id);
                    if (dep == null)
                        throw new System.InvalidOperationException("Подразделение не найдено.");

                    bool exists = db.Departments.Any(d => d.Name == name && d.Id != id);
                    if (exists)
                        throw new System.InvalidOperationException("Подразделение с таким названием уже существует.");

                    dep.Name = name;
                    db.SaveChanges();
                }
            }

            public void Delete(int id)
            {
                using (var db = new DLADbContext())
                {
                    
                    bool hasEmployees = db.Employees.Any(e => e.DepartmentId == id);
                    if (hasEmployees)
                        throw new InvalidOperationException("Нельзя удалить отделение: в нём есть сотрудники.");

                    var dep = db.Departments.FirstOrDefault(d => d.Id == id);
                    if (dep == null) return;

                    db.Departments.Remove(dep);
                    db.SaveChanges();
                }
            }
        }
    }
}