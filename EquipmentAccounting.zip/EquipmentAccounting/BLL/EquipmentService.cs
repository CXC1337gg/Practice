﻿using DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BLL
{
    public class EquipmentService
    {
        public class EquipmentListItem
        {
            public int Id { get; set; }
            public string InventoryNumber { get; set; } = "";
            public string EquipmentType { get; set; } = "";
            public string? Employee { get; set; }
        }

        public List<EquipmentListItem> GetAll()
        {
            using (var db = new DLADbContext())
            {
                return db.Equipments
                     .Include(e => e.EquipmentType)
                     .Include(e => e.Employee)
                     .OrderBy(e => e.InventoryNumber)
                     .Select(e => new EquipmentListItem
                     {
                         Id = e.Id,
                         InventoryNumber = e.InventoryNumber,
                         EquipmentType = e.EquipmentType.Name,
                         Employee = e.Employee == null ? null : e.Employee.FullName
                     })
                     .ToList();
            }
        }

        public Entity.Equipment? GetById(int id)
        {
            using (var db = new DLADbContext())
            {
                return db.Equipments
                    .Include(e => e.EquipmentType)
                    .Include(e => e.Employee)
                    .FirstOrDefault(e => e.Id == id);
            }
        }

        public void Add(string inventoryNumber, int equipmentTypeId, int? employeeId)
        {
            using (var db = new DLADbContext())
            {
                inventoryNumber = (inventoryNumber ?? "").Trim();
                if (string.IsNullOrWhiteSpace(inventoryNumber))
                    throw new ArgumentException("Инвентарный номер обязателен.");

                
                bool invExists = db.Equipments.Any(e => e.InventoryNumber == inventoryNumber);
                if (invExists)
                    throw new InvalidOperationException("Инвентарный номер должен быть уникальным.");

                
                bool typeExists = db.EquipmentTypes.Any(t => t.Id == equipmentTypeId);
                if (!typeExists)
                    throw new InvalidOperationException("Тип оборудования не найден.");

                
                if (employeeId.HasValue)
                {
                    bool empExists = db.Employees.Any(emp => emp.Id == employeeId.Value);
                    if (!empExists)
                        throw new InvalidOperationException("Сотрудник не найден.");
                }

                var equipment = new Entity.Equipment
                {
                    InventoryNumber = inventoryNumber,
                    EquipmentTypeId = equipmentTypeId,
                    EmployeeId = employeeId
                };

                db.Equipments.Add(equipment);
                db.SaveChanges();
            }
        }

        public void Update(int id, string inventoryNumber, int equipmentTypeId, int? employeeId)
        {
            using (var db = new DLADbContext())
            {
                inventoryNumber = (inventoryNumber ?? "").Trim();
                if (string.IsNullOrWhiteSpace(inventoryNumber))
                    throw new ArgumentException("Инвентарный номер обязателен.");

                var equipment = db.Equipments.FirstOrDefault(e => e.Id == id);
                if (equipment == null)
                    throw new InvalidOperationException("Оборудование не найдено.");

                
                bool invExists = db.Equipments.Any(e => e.InventoryNumber == inventoryNumber && e.Id != id);
                if (invExists)
                    throw new InvalidOperationException("Инвентарный номер должен быть уникальным.");

                bool typeExists = db.EquipmentTypes.Any(t => t.Id == equipmentTypeId);
                if (!typeExists)
                    throw new InvalidOperationException("Тип оборудования не найден.");

                if (employeeId.HasValue)
                {
                    bool empExists = db.Employees.Any(emp => emp.Id == employeeId.Value);
                    if (!empExists)
                        throw new InvalidOperationException("Сотрудник не найден.");
                }

                equipment.InventoryNumber = inventoryNumber;
                equipment.EquipmentTypeId = equipmentTypeId;
                equipment.EmployeeId = employeeId;

                db.SaveChanges();
            }
        }

        public void Delete(int id)
        {
            using (var db = new DLADbContext())
            {
                var equipment = db.Equipments.FirstOrDefault(e => e.Id == id);
                if (equipment == null) return;

                db.Equipments.Remove(equipment);
                db.SaveChanges();
            }
        }
    }
}