﻿using DAL;
using Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EquipmentAccounting2
{
    public partial class DepartmentForm : Form
    {
        private readonly DLADbContext _context;

        public DepartmentForm()
        {
            InitializeComponent();
            _context = new DLADbContext();
            LoadData();
        }

        private void LoadData()
        {
            dataGridView1.DataSource = _context.Departments.ToList();


            if (dataGridView1.Columns.Contains("Id"))
                dataGridView1.Columns["Id"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            _context.Departments.Add(new Department { Name = "Новое подразделение" });
            _context.SaveChanges();
            LoadData();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            if (dataGridView1.CurrentRow.DataBoundItem is not Department department)
                return;

            department.Name = (department.Name ?? string.Empty) + " (изм)";
            _context.SaveChanges();
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            if (dataGridView1.CurrentRow.DataBoundItem is not Department department)
                return;

            _context.Departments.Remove(department);
            _context.SaveChanges();
            LoadData();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _context.Dispose();
            base.OnFormClosed(e);
        }
    }
}
