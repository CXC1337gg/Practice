using DAL;
using Entity;

namespace DepartmentForm
{
    public partial class DepartmentForm : Form
    {
        private readonly DLADbContext _context;
        public DepartmentForm()
        {
            InitializeComponent();
            _context = new DLADbContext();
            LoadData();
        }

        private void LoadData()
        {
            dgvDepartments.DataSource = _context.Departments.ToList();
            dgvDepartments.Columns["Id"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            _context.Departments.Add(new Department { Name = "����� �������������" });
            _context.SaveChanges();
            LoadData();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvDepartments.CurrentRow == null) return;

            var department = dgvDepartments.CurrentRow.DataBoundItem as Department;
            department.Name += " (���)";
            _context.SaveChanges();
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvDepartments.CurrentRow == null) return;

            var department = dgvDepartments.CurrentRow.DataBoundItem as Department;
            _context.Departments.Remove(department);
            _context.SaveChanges();
            LoadData();
        }
    }
}
