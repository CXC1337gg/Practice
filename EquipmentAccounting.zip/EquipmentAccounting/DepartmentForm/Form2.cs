using DAL;
using Entity;

namespace DepartmentForm
{
    public partial class Form2 : Form
    {
        private readonly DLADbContext _context;

        public Form2()
        {
            InitializeComponent();
            _context = new DLADbContext();
            LoadData();
        }

        private void LoadData()
        {
            dataGridView1.DataSource = _context.Departments.ToList();

            
            if (dataGridView1.Columns.Contains("Id"))
                dataGridView1.Columns["Id"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            _context.Departments.Add(new Department { Name = "����� �������������" });
            _context.SaveChanges();
            LoadData();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            if (dataGridView1.CurrentRow.DataBoundItem is not Department department)
                return;

            department.Name = (department.Name ?? string.Empty) + " (���)";
            _context.SaveChanges();
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null) return;

            if (dataGridView1.CurrentRow.DataBoundItem is not Department department)
                return;

            _context.Departments.Remove(department);
            _context.SaveChanges();
            LoadData();
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _context.Dispose();
            base.OnFormClosed(e);
        }
    }
}
