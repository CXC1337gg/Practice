﻿namespace EquipmentAccounting
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            treeView1 = new TreeView();
            panelContent = new Panel();
            menuStrip2 = new MenuStrip();
            файлToolStripMenuItem = new ToolStripMenuItem();
            listBox1 = new ListBox();
            panel1 = new Panel();
            menuStrip2.SuspendLayout();
            SuspendLayout();
            // menuStrip2
            // 
            menuStrip2.Items.AddRange(new ToolStripItem[] { файлToolStripMenuItem });
            menuStrip2.Location = new Point(0, 0);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(1198, 24);
            menuStrip2.TabIndex = 0;
            menuStrip2.Text = "menuStrip2";
            // 
            // файлToolStripMenuItem
            // 
            файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            файлToolStripMenuItem.Size = new Size(48, 20);
            файлToolStripMenuItem.Text = "Файл";
            // 
            // listBox1
            // 
            listBox1.DataSource = listBox1.CustomTabOffsets;
            listBox1.Dock = DockStyle.Left;
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(0, 24);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(207, 522);
            listBox1.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(207, 24);
            panel1.Name = "panel1";
            panel1.Size = new Size(991, 522);
            panel1.TabIndex = 2;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1198, 546);
            Controls.Add(panel1);
            Controls.Add(listBox1);
            Controls.Add(menuStrip2);
            MainMenuStrip = menuStrip2;
            Name = "MainForm";
            Text = "MainForm";
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }
        private System.Windows.Forms.MenuStrip menuStrip1; 
        private System.Windows.Forms.TreeView treeView1; 
        private System.Windows.Forms.Panel panelContent;

        #endregion

        private MenuStrip menuStrip2;
        private ToolStripMenuItem файлToolStripMenuItem;
        private ListBox listBox1;
        private Panel panel1;
    }
}
