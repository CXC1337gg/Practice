﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class EquipmentType
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public IEnumerable<Equipment> Equipments { get; set; }
    }
}
