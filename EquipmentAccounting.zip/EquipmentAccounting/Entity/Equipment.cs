﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entity
{
    public class Equipment
    {
        public int Id { get; set; }
        public string InventoryNumber { get; set; }

        public int EquipmentTypeId { get; set; }
        public EquipmentType EquipmentType { get; set; }

        public int? EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
