﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public static class Seed
    {
        public static void SeedData(DLADbContext context)
        {
            // Подразделения
            if (!context.Departments.Any())
            {
                context.Departments.AddRange(
                    new Department[]
                    {
                        new Department { Name = "Департамент информационных технологий" },
                        new Department { Name = "Финансово-экономический отдел" },
                        new Department { Name = "Управление персоналом" },
                        new Department { Name = "Руководящий аппарат" },
                        new Department { Name = "Отдел информационной безопасности" }
                    });
            }

            // Типы оборудования
            if (!context.EquipmentTypes.Any())
            {
                context.EquipmentTypes.AddRange(
                    new EquipmentType[]
                    {
                        new EquipmentType { Name = "Мобильная рабочая станция", Description = "Профессиональный ноутбук для инженеров и разработчиков" },
                        new EquipmentType { Name = "Рабочая станция", Description = "Мощный настольный компьютер для офисных задач и проектирования" },
                        new EquipmentType { Name = "ЖК-монитор", Description = "Плоскопанельный дисплей с Full HD разрешением" },
                        new EquipmentType { Name = "Многофункциональное устройство", Description = "Принтер, сканер и копир в одном корпусе" },
                        new EquipmentType { Name = "Сетевой коммутатор", Description = "Устройство для объединения компьютеров в локальную сеть" }
                    });
            }

            // Сотрудники
            if (!context.Employees.Any())
            {
                context.Employees.AddRange(
                    new Employee[]
                    {
                        new Employee { FullName = "Кузнецов А.В.", DepartmentId = 1 },
                        new Employee { FullName = "Морозова Е.С.", DepartmentId = 1 },
                        new Employee { FullName = "Волков Д.Н.", DepartmentId = 2 }
                    });
            }

            context.SaveChanges();
        }
    }
}
