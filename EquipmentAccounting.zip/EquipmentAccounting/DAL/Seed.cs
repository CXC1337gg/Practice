﻿using Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace DAL
{
    public static class Seed
    {
        public static void SeedData(DLADbContext context)
        {
            // Подразделения
            if (!context.Departments.Any())
            {
                context.Departments.AddRange(
                    new Department[]
                    {
                        new Department { Name = "Отдел разработки ПО" },
                        new Department { Name = "Финансовый отдел" },
                        new Department { Name = "HR-департамент" },
                        new Department { Name = "Юридический отдел" },
                        new Department { Name = "Отдел маркетинга" },
                        new Department { Name = "Техническая поддержка" },
                        new Department { Name = "Отдел логистики" }
                    });
            }

            // Типы оборудования
            if (!context.EquipmentTypes.Any())
            {
                context.EquipmentTypes.AddRange(
                    new EquipmentType[]
                    {
                        new EquipmentType { Name = "Сервер", Description = "Высокопроизводительный компьютер для хранения и обработки данных" },
                        new EquipmentType { Name = "Ноутбук Dell Latitude", Description = "Корпоративный ноутбук для мобильных сотрудников" },
                        new EquipmentType { Name = "Монитор Dell UltraSharp", Description = "Профессиональный монитор с высоким разрешением" },
                        new EquipmentType { Name = "МФУ HP LaserJet", Description = "Многофункциональное печатающее устройство" },
                        new EquipmentType { Name = "Проектор Epson", Description = "Устройство для презентаций и совещаний" },
                        new EquipmentType { Name = "IP-телефон", Description = "Голосовая связь через интернет" },
                        new EquipmentType { Name = "Сетевой коммутатор", Description = "Оборудование для управления сетевым трафиком" }
                    });
            }

            // Сотрудники
            if (!context.Employees.Any())
            {
                context.Employees.AddRange(
                    new Employee[]
                    {
                        new Employee { FullName = "Козлов А.С.", DepartmentId = 1 },
                        new Employee { FullName = "Морозова Е.В.", DepartmentId = 1 },
                        new Employee { FullName = "Лебедев Д.К.", DepartmentId = 1 },
                        new Employee { FullName = "Фёдорова Н.П.", DepartmentId = 2 },
                        new Employee { FullName = "Соколова И.М.", DepartmentId = 3 },
                        new Employee { FullName = "Григорьев Р.А.", DepartmentId = 5 },
                        new Employee { FullName = "Волкова Т.Ю.", DepartmentId = 6 }
                    });
            }

            context.SaveChanges();
        }
    }
}